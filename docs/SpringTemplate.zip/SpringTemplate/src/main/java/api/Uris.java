package api;

public class Uris {

    public static final String SERVLET_MAP = "/api";

    public static final String VERSION = "/v0";

}
